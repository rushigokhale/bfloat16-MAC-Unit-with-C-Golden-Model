# bf16 MAC: Specification (the contract the testbench checks)

## Function
`result = acc + a * b`, computed with a **single rounding**.

| Port     | Format                                              |
|----------|-----------------------------------------------------|
| `a`, `b` | bfloat16: 1 sign, 8 exponent (bias 127), 7 fraction |
| `acc`    | IEEE-754 binary32                                   |
| `result` | IEEE-754 binary32                                   |

The product of two bf16 values has at most 16 significant bits, so it is exact
in binary32 (24 bits). The only rounding in the whole operation is the final one.

## Numeric rules
1. **Rounding:** round-to-nearest, ties-to-even, applied once to the exact `acc + a*b`.
2. **Denormal inputs (DAZ):** any input with exponent field 0 is treated as a signed zero
   (the fraction is ignored). Applies to `a`, `b` and `acc`.
3. **Underflow (FTZ):** the result is rounded to 24 bits of precision assuming an
   unbounded exponent range. If the resulting biased exponent is <= 0, the result is a
   zero carrying the sign of the exact result. No denormal is ever produced.
4. **Overflow:** if the rounded biased exponent is >= 255, the result is infinity
   with the sign of the exact result.
5. **NaN:** any NaN input gives the canonical quiet NaN `0x7FC00000`.
   `inf * 0` and `inf + (-inf)` also give `0x7FC00000`. NaN payload and sign are never propagated.
6. **Infinity:** `inf * finite_nonzero` is a signed infinity. A signed infinity plus a finite
   `acc` is that infinity. Infinity plus an opposite-signed infinity is NaN.
7. **Zero signs:**
   * `(+0) + (+0) = +0`, `(-0) + (-0) = -0`, mixed signs give `+0`.
   * Exact cancellation of nonzero values gives `+0` (round-to-nearest rule).
   * The product sign is `sign(a) ^ sign(b)`, also for zero products.

## Interface and timing
* Fully pipelined, no stalls, one operation per cycle.
* `in_valid` at cycle N gives `out_valid` + `result` at cycle N+3 (fixed latency 3).
* `out_valid` is low when no valid input was presented 3 cycles earlier.
* Synchronous active-low reset `rst_n` clears the valid pipeline (in-flight operations are dropped).

## Systolic array (`bf16_systolic`, N x N, weight-stationary)
* `W[r][c]` (bf16) is preloaded through a write port.
* Each cycle a vector `x[0..N-1]` (bf16) may be presented with `x_valid`.
* After a fixed latency of `6N-3` cycles the module presents `y[0..N-1]` (fp32) with `y_valid`, where
  `y[c] = (((0 + x0*W0c) + x1*W1c) + ... + x(N-1)*W(N-1)c)`, each step being one `bf16_mac`
  operation (so the result is bit-exact against a chain of golden-model MACs).
